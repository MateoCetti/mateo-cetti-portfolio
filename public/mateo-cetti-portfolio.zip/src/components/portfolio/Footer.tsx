import { useTranslation } from "react-i18next";
import { Github } from "lucide-react";
import { profile } from "@/data/portfolio";

export const Footer = () => {
  const { t } = useTranslation();
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-border/60 py-8">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-5 sm:flex-row sm:px-8">
        <p className="font-mono text-xs text-muted-foreground">
          {t("footer.rights", { year })}
        </p>
        <div className="flex items-center gap-4">
          <p className="font-mono text-xs text-muted-foreground">{t("footer.built")}</p>
          <a
            href={profile.githubUrl}
            target="_blank"
            rel="noreferrer"
            aria-label="GitHub profile"
            className="text-muted-foreground transition-colors hover:text-primary"
          >
            <Github className="size-4" />
          </a>
        </div>
      </div>
    </footer>
  );
};
